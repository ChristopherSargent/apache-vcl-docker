This application has only been tested with the lic_setup_data.txt configuration file.
This configuration file contains the esxFull setup

It should work with esxBasic with addon features, but that configuration has not been tested.
